package com.pikai.complex.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pikai.complex.annotation.Controller;

@Controller("/hello")
public class HelloController {
	public void index(HttpServletRequest request, HttpServletResponse response) throws Exception {
		try {
			request.getRequestDispatcher("/WEB-INF/jsp/DispatchServlet.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}