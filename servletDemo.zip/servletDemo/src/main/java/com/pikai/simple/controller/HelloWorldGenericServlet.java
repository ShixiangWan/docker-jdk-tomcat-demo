package com.pikai.simple.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

@SuppressWarnings("serial")
public class HelloWorldGenericServlet extends GenericServlet {

	@Override
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			PrintWriter printWriter = response.getWriter();
			printWriter.println("<h1>hello,generic world.!!!</h1>");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}